"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    MONGO_URI: 'mongodb+srv://bootcamp-user:bootcamp-password@node-db-bootcamp.u0sqx.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
    PORT: 5000,
    TOKEN_SECRET: 'my-secret-hash'
};
